<?php
// created: 2017-01-04 13:31:44
$dictionary["Terri_Territoire"]["fields"]["thin_cycleplans_terri_territoire"] = array (
  'name' => 'thin_cycleplans_terri_territoire',
  'type' => 'link',
  'relationship' => 'thin_cycleplans_terri_territoire',
  'source' => 'non-db',
  'module' => 'Thin_CyclePlans',
  'bean_name' => 'Thin_CyclePlans',
  'side' => 'right',
  'vname' => 'LBL_THIN_CYCLEPLANS_TERRI_TERRITOIRE_FROM_THIN_CYCLEPLANS_TITLE',
);
