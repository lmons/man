<?php

    //Dashboard Manager
    $mod_strings['LBL_ADMIN_VERSION_FAIL'] = 'Dashboard Manager is not supported for this version of SugarCRM and has been disabled. Please check SugarForge for an updated package.';
    $mod_strings['LBL_CONFIRM_RESTORE'] = 'Are you sure you want to restore your default dashboard?';
    $mod_strings['LBL_RESTORE_LINK_TEXT'] = 'Restore My Dashboard';