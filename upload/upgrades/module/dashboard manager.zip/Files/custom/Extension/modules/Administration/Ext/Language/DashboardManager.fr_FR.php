<?php

    //Dashboard Manager
    $mod_strings['LBL_DASHBOARD_MANAGEMENT'] = 'Gestionnaire de page d&#39;accueil';
    $mod_strings['LBL_DASHBOARD_MANAGER'] = 'Modèles de page d&#39;accueil';
    $mod_strings['LBL_DASHBOARD_BACKUPS'] = 'Sauvegardes de page d&#39;accueil';
    $mod_strings['LBL_DASHBOARD_MANAGER_DESCRIPTION'] = 'Gestion des modèles de page d&#39;accueil';
    $mod_strings['LBL_DASHBOARD_BACKUPS_DESCRIPTION'] = 'Gestion des sauvegardes de page d&#39;accueil';
