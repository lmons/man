Dashboard Manager
================
This is a module loadable plugin for use with SugarCRM.

The 'InstallerPackage' directory contains the files for the actual installer zip. To create an installer, you will need to zip the contents of this directory excluding the base 'InstallerPackage' directory.

The 'ModuleBuilder' directory contains the initial Module Builder files the package was created from.

<hr>
<a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/deed.en_US"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-sa/3.0/80x15.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/deed.en_US">Creative Commons Attribution-ShareAlike 3.0 Unported License</a> with original attribution remaining with Gerald Clark (https://github.com/geraldclark/DashboardManager/).