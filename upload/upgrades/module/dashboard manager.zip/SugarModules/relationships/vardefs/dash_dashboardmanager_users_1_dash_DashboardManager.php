<?php
// created: 2012-08-23 23:17:02
$dictionary["dash_DashboardManager"]["fields"]["dash_dashboardmanager_users_1"] = array (
  'name' => 'dash_dashboardmanager_users_1',
  'type' => 'link',
  'relationship' => 'dash_dashboardmanager_users_1',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_DASH_DASHBOARDMANAGER_USERS_1_FROM_USERS_TITLE',
);
