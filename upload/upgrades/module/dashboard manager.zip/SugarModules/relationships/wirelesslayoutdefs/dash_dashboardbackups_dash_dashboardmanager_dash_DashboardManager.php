<?php
 // created: 2012-08-23 23:17:02
$layout_defs["dash_DashboardManager"]["subpanel_setup"]['dash_dashboardbackups_dash_dashboardmanager'] = array (
  'order' => 100,
  'module' => 'dash_DashboardBackups',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DASH_DASHBOARDBACKUPS_DASH_DASHBOARDMANAGER_FROM_DASH_DASHBOARDBACKUPS_TITLE',
  'get_subpanel_data' => 'dash_dashboardbackups_dash_dashboardmanager',
);
