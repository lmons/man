<?php
// created: 2017-01-04 14:47:25
$dictionary["Contact"]["fields"]["thin_cycleplantargets_contacts"] = array (
  'name' => 'thin_cycleplantargets_contacts',
  'type' => 'link',
  'relationship' => 'thin_cycleplantargets_contacts',
  'source' => 'non-db',
  'module' => 'Thin_CyclePlanTargets',
  'bean_name' => 'Thin_CyclePlanTargets',
  'side' => 'right',
  'vname' => 'LBL_THIN_CYCLEPLANTARGETS_CONTACTS_FROM_THIN_CYCLEPLANTARGETS_TITLE',
);
