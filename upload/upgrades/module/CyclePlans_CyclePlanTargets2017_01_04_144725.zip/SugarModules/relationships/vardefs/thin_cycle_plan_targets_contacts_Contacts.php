<?php
// created: 2017-01-03 13:52:51
$dictionary["Contact"]["fields"]["thin_cycle_plan_targets_contacts"] = array (
  'name' => 'thin_cycle_plan_targets_contacts',
  'type' => 'link',
  'relationship' => 'thin_cycle_plan_targets_contacts',
  'source' => 'non-db',
  'module' => 'Thin_CyclePlanTargets',
  'bean_name' => 'Thin_CyclePlanTargets',
  'vname' => 'LBL_THIN_CYCLE_PLAN_TARGETS_CONTACTS_FROM_THIN_CYCLEPLANTARGETS_TITLE',
);
