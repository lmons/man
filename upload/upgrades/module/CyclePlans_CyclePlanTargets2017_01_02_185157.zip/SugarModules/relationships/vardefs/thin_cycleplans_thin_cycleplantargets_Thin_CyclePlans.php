<?php
// created: 2017-01-02 18:51:57
$dictionary["Thin_CyclePlans"]["fields"]["thin_cycleplans_thin_cycleplantargets"] = array (
  'name' => 'thin_cycleplans_thin_cycleplantargets',
  'type' => 'link',
  'relationship' => 'thin_cycleplans_thin_cycleplantargets',
  'source' => 'non-db',
  'module' => 'Thin_CyclePlanTargets',
  'bean_name' => 'Thin_CyclePlanTargets',
  'side' => 'right',
  'vname' => 'LBL_THIN_CYCLEPLANS_THIN_CYCLEPLANTARGETS_FROM_THIN_CYCLEPLANTARGETS_TITLE',
);
